from typing import Literal

BackgroundAttachment = Literal[
    'fixed',
    'local',
    'scroll',
]
