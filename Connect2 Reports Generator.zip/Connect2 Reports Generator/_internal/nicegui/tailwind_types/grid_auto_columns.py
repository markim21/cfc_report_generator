from typing import Literal

GridAutoColumns = Literal[
    'auto',
    'min',
    'max',
    'fr',
]
