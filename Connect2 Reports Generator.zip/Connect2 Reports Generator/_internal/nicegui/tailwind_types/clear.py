from typing import Literal

Clear = Literal[
    'start',
    'end',
    'left',
    'right',
    'both',
    'none',
]
