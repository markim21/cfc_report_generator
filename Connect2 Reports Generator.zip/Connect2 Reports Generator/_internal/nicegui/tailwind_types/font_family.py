from typing import Literal

FontFamily = Literal[
    'sans',
    'serif',
    'mono',
]
