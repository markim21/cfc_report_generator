from typing import Literal

JustifyItems = Literal[
    'start',
    'end',
    'center',
    'stretch',
]
