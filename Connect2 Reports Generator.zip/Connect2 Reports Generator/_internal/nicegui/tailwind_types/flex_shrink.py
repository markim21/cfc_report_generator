from typing import Literal

FlexShrink = Literal[
    '',
    '0',
]
