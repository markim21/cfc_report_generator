from typing import Literal

Animation = Literal[
    'none',
    'spin',
    'ping',
    'pulse',
    'bounce',
]
