from typing import Literal

DivideWidth = Literal[
    'x-0',
    'x-2',
    'x-4',
    'x-8',
    'x',
    'y-0',
    'y-2',
    'y-4',
    'y-8',
    'y',
    'y-reverse',
    'x-reverse',
]
