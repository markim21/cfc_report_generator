from typing import Literal

ScreenReaders = Literal[
    'sr-only',
    'not-sr-only',
]
