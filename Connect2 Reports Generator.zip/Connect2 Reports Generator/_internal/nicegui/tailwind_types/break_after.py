from typing import Literal

BreakAfter = Literal[
    'auto',
    'avoid',
    'all',
    'avoid-page',
    'page',
    'left',
    'right',
    'column',
]
