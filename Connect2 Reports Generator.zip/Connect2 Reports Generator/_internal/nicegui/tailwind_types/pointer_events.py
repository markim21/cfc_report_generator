from typing import Literal

PointerEvents = Literal[
    'none',
    'auto',
]
