from typing import Literal

AlignSelf = Literal[
    'auto',
    'start',
    'end',
    'center',
    'stretch',
    'baseline',
]
