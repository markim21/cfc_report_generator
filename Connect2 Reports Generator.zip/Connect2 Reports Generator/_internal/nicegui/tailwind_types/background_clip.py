from typing import Literal

BackgroundClip = Literal[
    'border',
    'padding',
    'content',
    'text',
]
