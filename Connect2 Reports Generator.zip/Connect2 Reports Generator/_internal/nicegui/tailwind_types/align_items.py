from typing import Literal

AlignItems = Literal[
    'start',
    'end',
    'center',
    'baseline',
    'stretch',
]
