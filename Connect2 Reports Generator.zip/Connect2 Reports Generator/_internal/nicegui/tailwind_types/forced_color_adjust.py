from typing import Literal

ForcedColorAdjust = Literal[
    'auto',
    'none',
]
