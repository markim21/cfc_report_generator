from typing import Literal

RingWidth = Literal[
    '0',
    '1',
    '2',
    '',
    '4',
    '8',
    'inset',
]
