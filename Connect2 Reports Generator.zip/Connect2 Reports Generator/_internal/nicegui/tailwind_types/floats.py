from typing import Literal

Floats = Literal[
    'start',
    'end',
    'right',
    'left',
    'none',
]
