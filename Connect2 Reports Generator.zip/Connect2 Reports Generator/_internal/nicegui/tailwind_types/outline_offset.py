from typing import Literal

OutlineOffset = Literal[
    '0',
    '1',
    '2',
    '4',
    '8',
]
