from typing import Literal

FlexWrap = Literal[
    'wrap',
    'wrap-reverse',
    'nowrap',
]
