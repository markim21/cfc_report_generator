from typing import Literal

AspectRatio = Literal[
    'auto',
    'square',
    'video',
]
