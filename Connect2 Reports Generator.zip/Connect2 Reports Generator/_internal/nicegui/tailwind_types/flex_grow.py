from typing import Literal

FlexGrow = Literal[
    '',
    '0',
]
