from typing import Literal

RingOffsetWidth = Literal[
    '0',
    '1',
    '2',
    '4',
    '8',
]
