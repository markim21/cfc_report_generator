from typing import Literal

OutlineWidth = Literal[
    '0',
    '1',
    '2',
    '4',
    '8',
]
