from typing import Literal

BackdropSaturate = Literal[
    '0',
    '50',
    '100',
    '150',
    '200',
]
